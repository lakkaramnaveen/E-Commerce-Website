import { Component } from '@angular/core';

@Component({
  selector: 'app-ec-footer',
  templateUrl: './ec-footer.component.html',
  styleUrls: ['./ec-footer.component.css']
})
export class EcFooterComponent {

}
