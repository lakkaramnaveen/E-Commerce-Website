import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EcSideComponent } from './ec-side.component';

describe('EcSideComponent', () => {
  let component: EcSideComponent;
  let fixture: ComponentFixture<EcSideComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EcSideComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EcSideComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
