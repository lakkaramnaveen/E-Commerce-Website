import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EcViewallProdComponent } from './ec-viewall-prod.component';

describe('EcViewallProdComponent', () => {
  let component: EcViewallProdComponent;
  let fixture: ComponentFixture<EcViewallProdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EcViewallProdComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EcViewallProdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
