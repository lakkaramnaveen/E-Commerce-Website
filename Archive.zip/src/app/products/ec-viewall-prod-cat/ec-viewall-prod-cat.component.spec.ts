import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EcViewallProdCatComponent } from './ec-viewall-prod-cat.component';

describe('EcViewallProdCatComponent', () => {
  let component: EcViewallProdCatComponent;
  let fixture: ComponentFixture<EcViewallProdCatComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EcViewallProdCatComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EcViewallProdCatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
