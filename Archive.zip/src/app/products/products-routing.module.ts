import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddToCartComponent } from './add-to-cart/add-to-cart.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { EcCreateProdComponent } from './ec-create-prod/ec-create-prod.component';
import { EcDelProdComponent } from './ec-del-prod/ec-del-prod.component';
import { EcUpdateProdComponent } from './ec-update-prod/ec-update-prod.component';
import { EcViewProdComponent } from './ec-view-prod/ec-view-prod.component';
import { EcViewallProdCatComponent } from './ec-viewall-prod-cat/ec-viewall-prod-cat.component';
import { EcViewallProdDateComponent } from './ec-viewall-prod-date/ec-viewall-prod-date.component';
import { EcViewallProdComponent } from './ec-viewall-prod/ec-viewall-prod.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

const routes: Routes = [
  { path: '', component: EcViewallProdComponent },
  { path: 'create-product', component: EcCreateProdComponent },
  { path: 'delete-product/:id', component: EcDelProdComponent },
  { path: 'product/:id', component: EcViewProdComponent },
  { path: 'update-product/:id', component: EcUpdateProdComponent },
  { path: 'add-product/:id', component: AddToCartComponent },
  { path: 'checkout/:id', component: CheckoutComponent },
  { path: 'search-date', component: EcViewallProdDateComponent },
  { path: 'category/:id', component: EcViewallProdCatComponent },
  { path: '**', component: PageNotFoundComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProductsRoutingModule { }
