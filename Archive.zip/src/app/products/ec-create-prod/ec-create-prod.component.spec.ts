import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EcCreateProdComponent } from './ec-create-prod.component';

describe('EcCreateProdComponent', () => {
  let component: EcCreateProdComponent;
  let fixture: ComponentFixture<EcCreateProdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EcCreateProdComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EcCreateProdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
