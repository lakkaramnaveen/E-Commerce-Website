import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EcViewProdComponent } from './ec-view-prod.component';

describe('EcViewProdComponent', () => {
  let component: EcViewProdComponent;
  let fixture: ComponentFixture<EcViewProdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EcViewProdComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EcViewProdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
