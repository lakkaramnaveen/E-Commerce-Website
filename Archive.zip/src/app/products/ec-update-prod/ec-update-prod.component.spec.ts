import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EcUpdateProdComponent } from './ec-update-prod.component';

describe('EcUpdateProdComponent', () => {
  let component: EcUpdateProdComponent;
  let fixture: ComponentFixture<EcUpdateProdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EcUpdateProdComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EcUpdateProdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
