import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-ec-viewall-prod-date',
  templateUrl: './ec-viewall-prod-date.component.html',
  styleUrls: ['./ec-viewall-prod-date.component.css']
})
export class EcViewallProdDateComponent {
  searchDate = '';

  constructor(private activatedRoute: ActivatedRoute){}

  ngOnInit(): void{
    this.activatedRoute.queryParams.subscribe(data => {
      this.searchDate = data['date'];
    })
  }
}
