import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EcViewallProdDateComponent } from './ec-viewall-prod-date.component';

describe('EcViewallProdDateComponent', () => {
  let component: EcViewallProdDateComponent;
  let fixture: ComponentFixture<EcViewallProdDateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EcViewallProdDateComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EcViewallProdDateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
